//
//  MovieGridCell.swift
//  Flixer
//
//  Created by Ishmam Haque on 9/17/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
